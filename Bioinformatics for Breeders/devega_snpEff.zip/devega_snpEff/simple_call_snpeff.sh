#!/bin/bash -e
#SBATCH -p tgac-medium # partition (queue)
#SBATCH -N 1 # number of nodes
#SBATCH -c 8 # number of tasks
#SBATCH --mem 50G # memory pool for all cores
#SBATCH -o snpeff.slurm.%N.%j.out # STDOUT
#SBATCH -e snpeff.slurm.%N.%j.err # STDERR
#SBATCH --mail-type=END,FAIL # notifications for job done & fail
#SBATCH --mail-user=kirstie.hetherington@tgac.ac.uk # send-to address

source jre-7.11;
source snpeff-4.2;

#BUILD DATABASE

java -jar /tgac/software/testing/bin/core/../..//snpeff/4.2/x86_64/bin/snpEff.jar build \
 -c /tgac/software/testing/snpeff/4.2/x86_64/bin/snpEff.willow.config -gff3 -v Salix_viminalis_TGAC_ROT_v2_scaffolds

java -jar /tgac/software/testing/bin/core/../..//snpeff/4.2/x86_64/bin/snpEff.jar -v \
 -c snpEff.willow3.config Salix_viminalis_TGAC_ROT_v2_scaffolds merged_non_chrom_default.vcf > try1.vcf


